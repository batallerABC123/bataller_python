#!/usr/bin/env ptyhon3

CA = "Classe A"
CB = "Classe B"
CC = "Classe C"

CAP = "Classe A privada"
CBP = "Classe B privada"
CCP = "Classe C privada"

print("Classes de direccions IP públiques:")
print(CA, "(1.0.0.0 - 126.255.255.255)")
print(CB, "(128.0.0.0 - 191.255.255.255)")
print(CC, "(192.0.0.0 - 223.255.255.255)")

print("\n")

print("Classes de direcciones IP privades:")
print(CAP, "(10.0.0.0 - 10.255.255.255)")
print(CBP, "(172.16.0.0 - 172.31.255.255)")
print(CCP, "(192.168.0.0 - 192.168.255.255)")