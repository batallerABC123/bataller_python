nombre= "BATALLER"

print("Hola a todos!")
print(f"Soy {nombre} y estoy programando??")
