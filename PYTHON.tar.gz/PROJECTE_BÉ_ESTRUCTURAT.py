respostes_correctes = []
respostes_usuari = [0,0,0,0,0,0,0,0,0,0]
from datetime import datetime
nom_usuari = ""

def demana_dades_user():
    user = input("Escriu el teu nom d'usuari: ")
    password = input("Escriu la teva password: ")
    return user, password

def registra_usuari(user, password):
    with open("usuaris.txt", "a") as arxiu:  
        arxiu.write(f"{user},{password}\n") 

def valida_login(user, password):
    with open("usuaris.txt", "r") as arxiu:
        for line in arxiu:
            stuser, stpassword = line.strip().split(",")  
            if user == stuser and password == stpassword:
                return True
    return False

def guarda_examen(assignatura, respostes):
    timestamp = datetime.now().strftime("%Y-%m-%d-%H-%M")
    with open(f"{timestamp}_{nom_usuari}_{assignatura}_.txt", "a") as arxiu:
        for pregunta, resposta in enumerate(respostes, start=1):
            arxiu.write(f"{resposta}\n")
        arxiu.write("")

def menu():
    global nom_usuari
    print("Hola bones, benvingut al programa 3tester. Aquí pots escollir quin test vols fer")
    logged = False
    while not logged:
        registrat = input("Abans de tot, estàs registrat? (yes, no): ").lower()
        if registrat == "no" or registrat == "n":
            user_nou, password_nou = demana_dades_user()
            registra_usuari(user_nou, password_nou)  
            print("T'has registrat correctament")
        elif registrat == "yes" or registrat == "y":
            user, password = demana_dades_user()
            if valida_login(user, password):
                print("Has iniciat sessió amb èxit")
                logged = True
                nom_usuari = user
            else:
                print("Error d'inici de sessió. Usuari o contrasenya incorrectes.")

    while True:
        print("\nQuè vols fer ara?")
        opcio = input("Indica quin la opció que vulguis fer escrivint el seu número:\n\n   1. Seguretat\n   2. Serveis de xarxa\n   3. WEB\n   4. CREAR TEST\n")

        if opcio in ['1', '2', '3', '4']:
            return opcio
        else:
            print("ERROR: Opció no vàlida")

def llegir_preguntes(nom_fitxer):
    preguntes = []
    with open(nom_fitxer, 'r') as fitxer:
        linies = fitxer.readlines()
        for i in range(0, len(linies), 5):
            pregunta = linies[i].strip()
            respostes = [linies[i+j].strip() for j in range(1, 5)]
            num=0
            for resp in respostes:
                
                if resp[:1] == "¬":
                    respostes[num] = resp[1:]
                    respostes_correctes.append(chr(65+num))
                num +=1
            preguntes.append((pregunta, respostes))
    return preguntes

def mostrar_pregunta(num , pregunta, respostes, respostes_usuari):
    print("\n\n\n*****************************************************************************************")
    print(pregunta)
    print("*****************************************************************************************\n")

    for i, resposta in enumerate(respostes):
        if respostes_usuari[num] == chr(65+i) :
            print("****",end="")

        print(f"{chr(65+i)}. {resposta}\n")
    print("------------------------------------------------------------------------------------------")

def calcular_resultat(respostes_usuari, respostes_correctes):
    iguals = sum(1 for a, b in zip(respostes_usuari, respostes_correctes) if a == b)
    return iguals

def principal():
    global respostes_usuari
    
    opcio = menu()
    if opcio == '1':
         nom_fitxer = 'seguretat.txt'
         assignatura = 'seguretat'
    elif opcio == '2':
         nom_fitxer = 'xarxes.txt'
         assignatura = 'xarxes'
    elif opcio == '3':
         nom_fitxer = 'web.txt'
         assignatura = 'web'
    elif opcio == '4':
         nom_fitxer = 'creat.txt'
         assignatura = 'nou_test'

    preguntes = llegir_preguntes(nom_fitxer)
    pregunta_actual = 0

    while pregunta_actual < len(preguntes):
        pregunta, respostes = preguntes[pregunta_actual]
        mostrar_pregunta(pregunta_actual, pregunta, respostes, respostes_usuari)

        resposta = input("Introdueix la teva resposta (A, B, C o D), 's' per a la següent pregunta o el número de pregunta: ")
        if resposta.lower() == 's':
            pregunta_actual += 1
        else:
            resposta = resposta.upper()
            if resposta in ['A', 'B', 'C', 'D']:
                #respostes_usuari.append(resposta.upper())
                respostes_usuari[pregunta_actual] = resposta
                pregunta_actual += 1
            else:
                try:
                    num_pregunta = int(resposta) - 1
                    if 0 <= num_pregunta < len(preguntes):
                        pregunta_actual = num_pregunta
                    else:
                        print("Aquesta pregunta no existeix. Torna a provar.")
                except ValueError:
                    print("Entrada no vàlida. Si us plau, introdueix 's' o el número de pregunta.")

    iguals = calcular_resultat(respostes_usuari, respostes_correctes)
    print("Respostes de l'usuari:", respostes_usuari)
    print("Tens un", iguals)

    print("S'esta guardant...")
    
    print("S'ha guardat correctament!")
    guarda_examen(assignatura, respostes_usuari)

if __name__ == "__main__":
    principal()

#La part 4 la de fer la Gift